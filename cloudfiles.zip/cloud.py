"""
Cloud - AI Study Agent for Students
Run:  streamlit run cloud.py

Install:  pip install anthropic streamlit requests gTTS edge-tts ddgs
Keys:     export ANTHROPIC_API_KEY="..."   (required)
          export PEXELS_API_KEY="..."      (optional, free at pexels.com/api)
"""
import asyncio
import io
import os
import re

import anthropic
import requests
import streamlit as st
from gtts import gTTS

try:
    import edge_tts
except ImportError:
    edge_tts = None

try:
    from ddgs import DDGS
except ImportError:
    try:
        from duckduckgo_search import DDGS
    except ImportError:
        DDGS = None

MODEL = "claude-sonnet-4-6"
HEADERS = {"User-Agent": "Cloud-StudyAgent/1.0 (educational project)"}
PEXELS_KEY = os.environ.get("PEXELS_API_KEY")

# ---------------------------------------------------------------- Languages
LANGUAGES = {
    "English": {"gtts": "en", "voice": "en-IN-NeerjaNeural"},
    "Telugu (తెలుగు)": {"gtts": "te", "voice": "te-IN-ShrutiNeural"},
    "Hindi (हिन्दी)": {"gtts": "hi", "voice": "hi-IN-SwaraNeural"},
    "Tamil (தமிழ்)": {"gtts": "ta", "voice": "ta-IN-PallaviNeural"},
    "Kannada (ಕನ್ನಡ)": {"gtts": "kn", "voice": "kn-IN-SapnaNeural"},
}

# ---------------------------------------------------------- Specializations
SPECIALIZATIONS = {
    "General": "You help with any school or college subject.",
    "Science (Physics/Chemistry)": (
        "You specialize in physics and chemistry. Explain the underlying principle, give "
        "the key formulas with units, include a simple real-life example, and suggest an "
        "experiment or working-model idea. Prefer diagrams when searching for images."
    ),
    "Biology": (
        "You specialize in biology. Use correct scientific terms with simple explanations, "
        "describe structures and processes step by step, and prefer labelled diagrams "
        "when searching for images."
    ),
    "Mathematics": (
        "You specialize in mathematics. Explain concepts intuitively, show worked examples "
        "step by step, state formulas clearly, and mention where the concept is used in "
        "real life. Prefer graphs and geometric figures when searching for images."
    ),
    "Computer Science": (
        "You specialize in computer science and programming. Explain concepts simply, give "
        "short, correct code examples (Python by default), describe how the program works, "
        "and suggest project ideas. Prefer architecture diagrams or flowcharts for images."
    ),
    "Engineering": (
        "You specialize in engineering projects. Cover the working principle, components, "
        "block diagram, applications, advantages and limitations, and a basic project "
        "report structure. Prefer circuit diagrams and machine photos for images."
    ),
    "History & Social Studies": (
        "You specialize in history, civics and social studies. Present events in "
        "chronological order with dates, causes and effects, and key people. Prefer "
        "historical photos, maps and monuments for images."
    ),
    "Geography & Environment": (
        "You specialize in geography and environmental science. Cover locations, climate, "
        "resources and human impact, and include current data where possible. Prefer maps "
        "and landscape photos for images."
    ),
    "English & Literature": (
        "You specialize in English and literature. Help with themes, characters, summaries, "
        "and writing structure. Explain ideas in the student's own-words style and do not "
        "write full essays for them to submit."
    ),
}

BASE_SYSTEM = """You are Cloud, a friendly project-work helper for students.

SAFETY AND LEARNING RULES
- Keep everything age-appropriate for school students. Politely decline anything violent,
  sexual, hateful, or dangerous, and gently steer back to the project.
- Help the student UNDERSTAND. Explain ideas, outline structure, give examples and hints.
  Do not write a complete assignment, essay, or report meant to be submitted as their own
  work. If asked to, give an outline and key points and encourage them to write it themselves.
- Never invent facts, numbers, quotes, or sources. If you are unsure or tools return
  nothing useful, say so.

HOW TO ANSWER
1. Gather facts: use search_facts (Wikipedia) for core concepts, and web_search for
   current, recent, or niche information (if available).
2. Get visuals: use find_images for diagrams, maps and charts, and find_photos for
   real-world photos (if available). One or two calls is enough.
3. Write a clear, well-organised answer with headings and bullets, in simple language.
   Cite facts with [1], [2] etc. matching the numbered sources in the tool results.
   Only cite numbers that actually appeared in tool results this turn.
4. End with a section titled exactly '## Summary' (keep this heading in English) holding a
   120-180 word spoken-style summary: plain sentences, no bullets, no markdown, no
   citation numbers. It will be read aloud.
5. For follow-up questions ("explain simpler", "give an example"), use the conversation so
   far and only call tools if new information is needed."""


def build_system(specialization: str, language: str) -> str:
    lang_name = language.split(" (")[0]
    return (
        f"{BASE_SYSTEM}\n\nSPECIALIZATION: {specialization}\n{SPECIALIZATIONS[specialization]}"
        f"\n\nLANGUAGE: Write the whole answer and the summary in {lang_name}. "
        "Keep the '## Summary' heading itself in English."
    )


# ------------------------------------------------------------------- Tools
def add_source(ctx: dict, title: str, url: str) -> int:
    for i, s in enumerate(ctx["sources"], 1):
        if s["url"] == url:
            return i
    ctx["sources"].append({"title": title, "url": url})
    return len(ctx["sources"])


def search_facts(query: str, ctx: dict) -> str:
    r = requests.get(
        "https://en.wikipedia.org/w/api.php",
        params={
            "action": "query", "format": "json", "generator": "search",
            "gsrsearch": query, "gsrlimit": 3, "prop": "extracts|info",
            "inprop": "url", "exintro": 1, "explaintext": 1, "exchars": 1500,
        },
        headers=HEADERS, timeout=15,
    )
    pages = r.json().get("query", {}).get("pages", {})
    if not pages:
        return "No results found."
    out = []
    for p in sorted(pages.values(), key=lambda p: p.get("index", 99)):
        n = add_source(ctx, f"{p['title']} (Wikipedia)", p.get("fullurl", ""))
        out.append(f"[{n}] {p['title']}\n{p.get('extract', '')}")
    return "\n\n".join(out)


def web_search(query: str, ctx: dict) -> str:
    results = DDGS().text(query, max_results=5)
    if not results:
        return "No results found."
    out = []
    for r in results:
        n = add_source(ctx, r.get("title", r["href"]), r["href"])
        out.append(f"[{n}] {r.get('title', '')}\n{r.get('body', '')}")
    return "\n\n".join(out)


def find_images(query: str, ctx: dict) -> str:
    """Diagrams, maps, charts from Wikimedia Commons (free, no key)."""
    r = requests.get(
        "https://commons.wikimedia.org/w/api.php",
        params={
            "action": "query", "format": "json", "generator": "search",
            "gsrsearch": f"filetype:bitmap {query}", "gsrnamespace": 6,
            "gsrlimit": 4, "prop": "imageinfo", "iiprop": "url", "iiurlwidth": 700,
        },
        headers=HEADERS, timeout=15,
    )
    pages = r.json().get("query", {}).get("pages", {})
    found = []
    for p in pages.values():
        info = (p.get("imageinfo") or [{}])[0]
        url = info.get("thumburl") or info.get("url")
        if url:
            caption = re.sub(r"^File:|\.\w+$", "", p["title"])
            ctx["images"].append({
                "url": url, "caption": caption,
                "credit": "Wikimedia Commons (check the licence before using)",
            })
            found.append(caption)
    return ("Found images: " + "; ".join(found)) if found else "No images found."


def find_photos(query: str, ctx: dict) -> str:
    """Real-world photos from Pexels (needs free PEXELS_API_KEY)."""
    r = requests.get(
        "https://api.pexels.com/v1/search",
        params={"query": query, "per_page": 4},
        headers={"Authorization": PEXELS_KEY}, timeout=15,
    )
    photos = r.json().get("photos", [])
    for p in photos:
        ctx["images"].append({
            "url": p["src"]["large"], "caption": p.get("alt") or query,
            "credit": f"Photo by {p['photographer']} on Pexels",
        })
    return f"Found {len(photos)} photos for '{query}'." if photos else "No photos found."


def tool_spec(name: str, description: str) -> dict:
    return {
        "name": name, "description": description,
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    }


TOOL_FUNCS = {"search_facts": search_facts, "find_images": find_images}
TOOLS = [
    tool_spec("search_facts", "Search Wikipedia for facts on a topic. Returns numbered, citable extracts."),
    tool_spec("find_images", "Find diagrams, maps, and charts from Wikimedia Commons."),
]
if DDGS is not None:
    TOOL_FUNCS["web_search"] = web_search
    TOOLS.append(tool_spec("web_search", "Search the web for current or niche information. Returns numbered, citable results."))
if PEXELS_KEY:
    TOOL_FUNCS["find_photos"] = find_photos
    TOOLS.append(tool_spec("find_photos", "Find real-world photographs from Pexels."))


# ------------------------------------------------------------- Agent loop
def run_agent(question, history, specialization, language):
    ctx = {"sources": [], "images": []}
    client = anthropic.Anthropic()
    system = build_system(specialization, language)
    messages = list(history) + [{"role": "user", "content": question}]

    for _ in range(10):  # safety cap on loop iterations
        try:
            resp = client.messages.create(
                model=MODEL, max_tokens=2500, system=system,
                tools=TOOLS, messages=messages,
            )
        except Exception as e:
            return f"Sorry, something went wrong talking to the AI: {e}", ctx
        messages.append({"role": "assistant", "content": resp.content})

        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if b.type == "text"), ctx

        results = []
        for b in resp.content:
            if b.type == "tool_use":
                try:
                    out = TOOL_FUNCS[b.name](b.input["query"], ctx)
                except Exception as e:
                    out = f"Tool error: {e}"
                results.append({"type": "tool_result", "tool_use_id": b.id, "content": out})
        messages.append({"role": "user", "content": results})

    return "Sorry, I couldn't finish this request. Please try a simpler question.", ctx


# ------------------------------------------------------------------- Audio
def clean_for_speech(text: str) -> str:
    text = re.sub(r"\[\d+\]", "", text)
    return re.sub(r"[*_#`>]", "", text).strip()


async def _edge_tts(text: str, voice: str) -> bytes:
    out = bytearray()
    async for chunk in edge_tts.Communicate(text, voice).stream():
        if chunk["type"] == "audio":
            out.extend(chunk["data"])
    return bytes(out)


def make_audio(summary: str, language: str) -> bytes:
    text = clean_for_speech(summary)
    cfg = LANGUAGES[language]
    if edge_tts is not None:  # natural neural voice
        try:
            data = asyncio.run(_edge_tts(text, cfg["voice"]))
            if data:
                return data
        except Exception:
            pass
    buf = io.BytesIO()  # fallback: gTTS
    gTTS(text=text, lang=cfg["gtts"]).write_to_fp(buf)
    return buf.getvalue()


# ---------------------------------------------------------------------- UI
def answer_turn(question, specialization, language):
    text, ctx = run_agent(question, st.session_state.history, specialization, language)
    parts = re.split(r"\n#{1,3}\s*Summary\s*\n", text, maxsplit=1)
    body = parts[0].strip()
    summary = parts[1].strip() if len(parts) > 1 else ""

    audio = None
    if summary:
        try:
            audio = make_audio(summary, language)
        except Exception:
            audio = None

    # Memory: keep the last few exchanges for follow-up questions
    st.session_state.history += [
        {"role": "user", "content": question},
        {"role": "assistant", "content": text},
    ]
    st.session_state.history = st.session_state.history[-12:]

    return {
        "question": question, "subject": specialization, "body": body,
        "summary": summary, "audio": audio,
        "images": ctx["images"][:6], "sources": ctx["sources"],
    }


def render_turn(t):
    with st.chat_message("user"):
        st.write(t["question"])
    with st.chat_message("assistant"):
        st.markdown(t["body"])
        if t["images"]:
            st.subheader("Photos and diagrams")
            cols = st.columns(2)
            for i, img in enumerate(t["images"]):
                cols[i % 2].image(img["url"], caption=f"{img['caption']} - {img['credit']}")
        if t["summary"]:
            st.subheader("Summary")
            st.write(t["summary"])
            if t["audio"]:
                st.audio(t["audio"], format="audio/mp3")
            else:
                st.caption("Audio could not be created this time.")
        if t["sources"]:
            st.subheader("Sources")
            for i, s in enumerate(t["sources"], 1):
                st.markdown(f"[{i}] [{s['title']}]({s['url']})")


st.set_page_config(page_title="Cloud", page_icon="🎓")
st.title("🎓 Cloud")
st.caption("Your project-work agent: answers, photos, sources and audio summary")

if not os.environ.get("ANTHROPIC_API_KEY"):
    st.error("Please set the ANTHROPIC_API_KEY environment variable and restart.")
    st.stop()

if "history" not in st.session_state:
    st.session_state.history = []
    st.session_state.turns = []

with st.sidebar:
    st.header("Settings")
    specialization = st.selectbox("Subject", list(SPECIALIZATIONS.keys()))
    language = st.selectbox("Language (answer and audio)", list(LANGUAGES.keys()))
    if st.button("Start new conversation"):
        st.session_state.history = []
        st.session_state.turns = []
        st.rerun()
    st.divider()
    st.caption("Features available")
    st.caption(f"{'✅' if DDGS else '❌'} Web search (pip install ddgs)")
    st.caption(f"{'✅' if PEXELS_KEY else '❌'} Pexels photos (set PEXELS_API_KEY)")
    st.caption(f"{'✅' if edge_tts else '❌'} Natural voice (pip install edge-tts)")

question = st.chat_input("Ask about your project, or follow up on the last answer...")
if question:
    with st.spinner(f"Cloud is researching ({specialization})..."):
        st.session_state.turns.append(answer_turn(question, specialization, language))

for t in st.session_state.turns:
    render_turn(t)
